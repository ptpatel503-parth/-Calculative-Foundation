# Calculative Foundation: Linear Algebra on Student Performance Data

**Red & White Skill Education | Duration: 6 hours | Type: Theory + Practical**

This project uses Linear Algebra (vectors, matrices, geometry, eigen-decomposition) to analyse the exam scores of 10 students across 5 subjects.

## Repository structure

```
.
├── README.md                        # this file
├── students_scores.csv              # dataset (10 students x 5 subjects)
├── linear_algebra_project.ipynb     # Jupyter notebook with code, charts, interpretations
├── theory_concepts.pdf              # theory notes with definitions and formulas
└── images/                          # charts exported from the notebook
```

## How to run

```bash
pip install numpy pandas matplotlib jupyter
jupyter notebook linear_algebra_project.ipynb
```
Run all cells; keep `students_scores.csv` in the same folder.

## Tasks covered

| Part | Task | Where |
|---|---|---|
| A1 | Student scores as vectors | Notebook, Part A |
| A2 | Norm-1 and Norm-2 | Notebook, Part A |
| A3 | Dot product and angle | Notebook, Part A |
| A4 | Cross product (Math, Physics, Chemistry) | Notebook, Part A |
| A5 | Projection of one vector onto another | Notebook, Part A |
| B4 | Student x subject matrix: addition, multiplication, transpose, inverse, determinant | Notebook, Part B |
| C5 | Line, plane, hyperplane | Notebook, Part C |
| C6 | Dimensionality 2D -> 3D -> higher | Notebook, Part C |
| D7 | Eigenvalues and eigenvectors of the covariance matrix | Notebook, Part D |

Every chart is labelled and has a short interpretation underneath it.

## Key results

- S1: Norm-1 = 405, Norm-2 = 181.75
- S1 . S2 = 26124, angle = 10.95 degrees (similar profiles)
- S1 x S2 (Math, Physics, Chemistry) = (314, -441, 94)
- Projection coefficient of S1 on S2 = 1.219
- 3x3 sub-matrix determinant = -1460, so it is invertible; the 10x5 matrix has no inverse (pseudo-inverse used)
- Line: Physics = 0.917 x Math + 4.156
- Covariance eigenvalues: 1168.0, 62.5, 10.9, 5.4, 1.3
- **PC1 explains 93.6%** of variance (overall science/technical ability); **PC2 explains 5.0%** (English vs science)

## Conclusion

The five subjects are effectively two-dimensional: Math, Physics, Chemistry and CompSci move together as one "overall ability" direction, while English is largely independent. Two principal components keep about 98.6% of the information.

## Tools

Python 3, NumPy, Pandas, Matplotlib, Jupyter Notebook.
